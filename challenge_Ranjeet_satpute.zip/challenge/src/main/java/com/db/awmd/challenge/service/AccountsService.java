package com.db.awmd.challenge.service;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.Transfer;
import com.db.awmd.challenge.repository.AccountsRepository;
import com.db.awmd.challenge.web.AccountsController;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccountsService {

	@Getter
	private final AccountsRepository accountsRepository;

	@Autowired
	NotificationService notification;

	@Autowired
	public AccountsService(AccountsRepository accountsRepository) {
		this.accountsRepository = accountsRepository;
	}

	public void createAccount(Account account) {
		this.accountsRepository.createAccount(account);
	}

	public Account getAccount(String accountId) {
		return this.accountsRepository.getAccount(accountId);
	}

	public boolean updateAccount(Transfer transfer) {
		if (transfer.getTransferAmount().intValue() > 0) {
			Account fromAccInfo = this.accountsRepository.getAccount(transfer.getFromAccountId());
			if (fromAccInfo.getBalance().intValue() > 0
					&& fromAccInfo.getBalance().intValue() >= transfer.getTransferAmount().intValue()) {
				withdrawAmt(fromAccInfo, transfer);
				Account toAccInfo = this.accountsRepository.getAccount(transfer.getToAccountId());
				depositAmt(toAccInfo, transfer);
				return true;
			} else {
				log.info("Account overdrafts");
				return false;
			}
		} else {
			log.info("Invalid Transfer Amount");
			return false;
		}
	}

	private synchronized void depositAmt(Account toAccInfo, Transfer transfer) {

		toAccInfo.setBalance(toAccInfo.getBalance().add(transfer.getTransferAmount()));
		this.accountsRepository.updateAccount(toAccInfo);
		notification.notifyAboutTransfer(toAccInfo, "Account credited with " + transfer.getTransferAmount());

	}

	private synchronized void withdrawAmt(Account fromAccInfo, Transfer transfer) {
		fromAccInfo.setBalance(fromAccInfo.getBalance().subtract(transfer.getTransferAmount()));
		this.accountsRepository.updateAccount(fromAccInfo);
		notification.notifyAboutTransfer(fromAccInfo, "Account debited with " + transfer.getTransferAmount());
	}

}
